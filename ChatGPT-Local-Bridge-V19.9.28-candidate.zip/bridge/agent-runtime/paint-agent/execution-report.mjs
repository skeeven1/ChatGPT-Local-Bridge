// V19.9.17 Paint execution report
// Keeps command, execution, observation and goal state separate.
export function createPaintExecutionReport(input={}) {
  return {
    commandReceived: Boolean(input.commandReceived),
    backendSelected: input.backendSelected ?? null,
    backendExecuted: Boolean(input.backendExecuted),
    evidenceChanged: Boolean(input.evidenceChanged),
    goalReached: Boolean(input.goalReached),
    failure: input.failure ?? null
  };
}
